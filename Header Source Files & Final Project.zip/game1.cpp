//FUNCTION 1
#include <iostream>
#include <string>
#include <iomanip>
#include "game2.cpp"
#include "numbers.h"

using namespace std;

//ALL NECESSARY VARIABLES TO CONTROL GAME
int gamenums[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
int guessNum;
int rannumber;
char play;
char name[10] = {'L', 'U', 'C', 'K', 'Y', 'L', 'O', 'T', 'T', 'O'};
char *output = name;
bool quit = false;
char contin;
string name3;

void game1()
{

    /*PROGRAM GENERATES RANDOM NUMBER SO IF USER ENTERS THEIR LUCKY NUMBER
    IT COULD BE THE LOTTO NUMBER OR NOT.
    */
    srand(time(NULL));
    int actNum = rand() % 10;

    /*GAME INTRO. ASKS USEER TO ENTER NAME. IF USER ENTERS E THEN GAME CONTINUES AND 
    IF THEY ENTER N, THEN PROGRAM BREAKS.
    */
    cout << "YOU CANNOT PLAY THIS GAME UNLESS YOU ENTER YOUR NAME. WE LIKE TO REMEMBER WHO WE STOLE MONEY FROM OVER TIME:\n\n";
    cin >> name3;

    cout << "______WELCOME TO LUCKY LOTTO " << name3 << ". IF YOU WOULD LIKE TO PLAY, HIT ENTER______\n";
    cout << "[E]: ";
    cin >> play;
    if (play == 'E' || play == 'e')
    {
        for (int i = 0; i < 10; i++)
        {
            cout << "--" << *output << "--"
                 << "\t";
            output++;
        }
    }
    else if (play == 'N' || play == 'n')
    {
        return;
    }

    /*CONTINUATION OF GAME. NUMBERS GET DISPLAYED IN A NEAT
    FORMAT USING /t MANIPULATION. IF USER GUESSES LOTTO NUMBER THEN
    THEY HIT THE JACKPOT AND CAN EITHER CASH OUT CHIPS OR CONTINUE TO
    GAME 2 TO QUADRUPLE THEIR CASH. 
    */
    cout << "\nPICK ANY NUMBER BETWEEN 1-1000:\n\n";
    cout << "CHOOSE WISELY["
         << "]: ";
    cin >> rannumber;
    if (rannumber > 0 && rannumber <= 1000)
    {
        cout << "\nOKAY, YOU PICKED " << rannumber << ". NOW YOU HAVE THE CHANCE TO TRIPLE THAT DOLLAR AMOUNT BY GUESSING THE NUMBER THAT I AM THINKING OF BETWEEN 1-10. TRY YOUR LUCK!!\n\n";
    }

    cout << "                         --GUESS WHAT NUMBER I AM THINKING OF--"
         << "\n";

    for (int x = 0; x < 10; x++)
    {
        cout << "\t" << gamenums[x];
    }
    for (int x = 0; x < 1; x++)
    {
        cout << "\n";
        cin >> guessNum;
        if (guessNum == actNum)
        {
            cout << "\n";
            int *numberPtr = &rannumber;
            tripleNumber(numberPtr);
            cout << name3 << ", $$$$!!YOU HAVE HIT THE JACKPOT!!$$$$\n"
                 << "NOW, YOU HAVE THE CHOICE TO QUADRUPLE YOUR MONEY OR CASH IT OUT.\nYOU CAN PRESS C TO GO FOR IT ALL OR E TO EXIT AND TAKE YOUR CHIPS TO THE COUNTER TO RECEIVE YOUR CASH.\n\n[C]"

                 << "[E]: ";
            cin >> contin;
            if (contin == 'C' || contin == 'c')
            {
                cout << "\n\n";
                return game2();
            }
            else if (contin == 'E' || contin == 'e')
            {
                cout << "TAKE YOUR CHIPS TO THE COUNTER AND CASH OUT "
                     << " $" << rannumber << "\n\n";
            }
        }

        else
        {

            char playy;
            int origbal = rannumber2;
            int changebal;
            change(&changebal, &origbal);
            cout << "*!!* YOU JUST LOST ALL OF YOUR MONEY *!!*\n";
            cout << "YOUR BALANCE IS NOW $" << origbal << "\n";
            cout << "NEXT TIME CHOOSE MORE WISELY. PRESS A IF YOU WANT TRY AGAIN. DON'T LOSE YOUR MONEY AGAIN HAHAHAHA...[A"
                 << "]: ";
            cin >> playy;
            if (playy == 'A' || playy == 'a')
            {
                return game1();
            }
            else
            {
                cout << "THANK YOU FOR PLAYING LUCKY LOTTO. HAVE A GREAT DAY";
                return;
            }
        }
    }
}
