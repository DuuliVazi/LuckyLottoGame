#include <iostream>
#include <string>
#include <iomanip>
#include "numbers.h"
#include "game1.cpp"

using namespace std;

//Michael Mindingall, 08/22/21, Header & Source Files.

int main()
{
    game1();
}
