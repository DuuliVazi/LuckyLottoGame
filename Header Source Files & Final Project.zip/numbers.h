//HEADER FILE FOR NUMBERS.CPP
#include <iostream>
#include <string>
#include <iomanip>

using namespace std;

//POINTER FXN TO TRIPLE NUMBER USER ENTERS
void tripleNumber(int *number);

//POINTER FXN TO QUADRUPLE NUMBER USER ENTERS
void quadrupleNumber(int *number2);

void change(int *origbal, int *changebal);