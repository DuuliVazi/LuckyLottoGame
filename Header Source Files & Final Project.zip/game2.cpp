//FUNCTION 2
#include <iostream>
#include <string>
#include <iomanip>
#include "numbers.cpp"
#include "numbers.h"



using namespace std;

//ALL NECESSARY VARIABLES TO CONTROL GAME
int gamenums2[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
int guessNum2;
int rannumber2;
char play2;
char name2[10] = {'L', 'U', 'C', 'K', 'Y', 'L', 'O', 'T', 'T', 'O'};
char *output2 = name2;
bool quit2 = false;
string name_;

void game2()
{
    /*PROGRAM GENERATES RANDOM NUMBER SO IF USER ENTERS THEIR LUCKY NUMBER
    IT COULD BE THE LOTTO NUMBER OR NOT.
    */
    srand(time(NULL));
    int actNum2 = rand() % 10;

    /*GAME INTRO. ASKS USEER TO ENTER NAME. IF USER ENTERS E THEN GAME CONTINUES AND 
    IF THEY ENTER N, THEN PROGRAM BREAKS.
    */
    cout << "YOU CANNOT PLAY THIS GAME UNLESS YOU ENTER YOUR NAME. WE LIKE TO REMEMBER WHO WE STOLE MONEY FROM OVER TIME:\n\n";
    cin >> name_;

    cout << "______NOW YOU CHOSE TO QUADRUPLE YOUR NUMBER. ENTER IF YOU DARE " << name_ << " .______\n";
    cout << "[E]: ";
    cin >> play2;
    if (play2 == 'E' || play2 == 'e')
    {
        for (int i = 0; i < 10; i++)
        {
            cout << "--" << *output2 << "--"
                 << "\t";
            output2++;
        }
    }
    else if (play2 == 'N' || play2 == 'n')
    {
        return;
    }

    /*CONTINUATION OF GAME. NUMBERS GET DISPLAYED IN A NEAT
    FORMAT USING /t MANIPULATION. IF USER GUESSES LOTTO NUMBER THEN
    THEY HIT THE JACKPOT AND CAN EITHER CASH OUT CHIPS OR CONTINUE TO
    GAME 2 TO QUADRUPLE THEIR CASH. 
    */
    cout << "\nPICK ANY NUMBER BETWEEN 1-1000:\n\n";
    cout << "CHOOSE WISELY["
         << "]: ";
    cin >> rannumber2;
    if (rannumber2 > 0 && rannumber2 <= 1000)
    {
        cout << "\nOKAY, YOU PICKED " << rannumber2 << ". NOW YOU HAVE THE CHANCE TO QUADRUPLE THAT DOLLAR AMOUNT BY GUESSING THE NUMBER THAT I AM THINKING OF BETWEEN 1-10. TRY YOUR LUCK!!\n\n";
    }

    cout << "                         --GUESS WHAT NUMBER I AM THINKING OF--"
         << "\n";

    for (int x = 0; x < 10; x++)
    {
        cout << "\t" << gamenums2[x];
    }
    for (int x = 0; x < 1; x++)
    {
        cout << "\n";
        cin >> guessNum2;
        if (guessNum2 == actNum2)
        {
            cout << "\n";
            int *numberPtr2 = &rannumber2;
            quadrupleNumber(numberPtr2);
            cout << name_ << ", $$$$!!YOU HAVE HIT THE JACKPOT!!$$$$\n"
                 << "TAKE YOUR CHIPS TO THE COUNTER AND CASH OUT "
                 << " $" << rannumber2 << "\n\n";
            quit2;
        }
        else
        {
            char playy2;
            int origbal = rannumber2;
            int changebal;
            change(&changebal, &origbal);
            cout << "*!!* YOU JUST LOST ALL OF YOUR MONEY *!!*\n";
            cout << "YOUR BALANCE IS NOW $" << origbal << "\n";
            cout << "NEXT TIME CHOOSE MORE WISELY. PRESS A IF YOU WANT TO START ALL OVER. DON'T LOSE YOUR MONEY AGAIN HAHAHAHA...[A"
                 << "]: ";
            cin >> playy2;
            if (playy2 == 'a' || playy2 == 'A')
            {
                return game2();
            }
            else
            {
                cout << "THANK YOU FOR PLAYING LUCKY LOTTO. HAVE A GREAT DAY\n";
                return;
            }
        }
    }
}
