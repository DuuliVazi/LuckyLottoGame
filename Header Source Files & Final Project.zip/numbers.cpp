//FUNCTION 3
#include <iostream>
#include <string>
#include "numbers.h"

using namespace std;

//TRIPLES NUMBER FROM ORIGINAL FXN IN NUMBERS.
void tripleNumber(int *number)
{
    *number = *number * 3;
}

//QUADRUPLES NUMBER FROM ORIGINAL FXN IN NUMBERS.
void quadrupleNumber(int *number2)
{
    *number2 = *number2 * 4;
}

//USER LOSES ALL MONEY IF THEY GUESS WRONG LOTTO NUMBER.
void change(int *origbal, int *changebal)
{
    *origbal = *origbal - *changebal;
}
